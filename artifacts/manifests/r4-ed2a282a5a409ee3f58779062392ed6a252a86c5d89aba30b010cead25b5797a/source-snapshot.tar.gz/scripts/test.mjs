import {spawnSync} from 'node:child_process';

for (const [command, args, extraEnv] of [
  [process.execPath, ['--test', '--test-concurrency=1', 'tests/reference/*.test.mjs', 'tests/contracts/*.test.mjs', 'tests/corpus/*.test.mjs', 'tests/episodes/*.test.mjs'], {}],
  [process.env.CONTRACT_PYTHON ?? '.venv/bin/python', ['-m', 'unittest', 'discover', '-s', 'tests/contracts', '-p', 'test_*.py'], {PYTHONPATH: 'python'}],
  [process.env.CONTRACT_PYTHON ?? '.venv/bin/python', ['-m', 'unittest', 'discover', '-s', 'tests/corpus', '-p', 'test_*.py'], {PYTHONPATH: 'python'}],
  [process.env.CONTRACT_PYTHON ?? '.venv/bin/python', ['-m', 'unittest', 'discover', '-s', 'tests/episodes', '-p', 'test_*.py'], {PYTHONPATH: 'python'}],
]) {
  const result = spawnSync(command, args, {stdio: 'inherit', env: {...process.env, ...extraEnv}});
  if (result.error) throw new Error(`Cannot run ${command}; see docs/R2_CONTRACT.md setup instructions`, {cause: result.error});
  if (result.status !== 0) process.exit(result.status ?? 1);
}
